equilibrium = list(map(int, input().split()))
right_sum = sum(equilibrium) - equilibrium[0]
left_sum = 0

for i in range(1, len(equilibrium)):
    right_sum -= equilibrium[i]
    left_sum += equilibrium[i-1]
    if left_sum == right_sum:
        print("Index:",i,"\nNumber:",equilibrium[i])

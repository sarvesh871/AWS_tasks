leader = list(map(int, input().split()))
right_max = leader[-1]
ans = []
ans.append(right_max)

for i in range(len(leader)-2, -1, -1):
    if leader[i] > right_max:
        right_max = leader[i]
        ans.append(right_max)

ans.reverse()
print(ans)

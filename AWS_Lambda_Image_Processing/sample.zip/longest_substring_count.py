str = input()
length_frequency = {}
left = 0
right = 0
count = 0
res = 0
vis = [False]*26

while right < len(str):
    while vis[ord(str[right]) - ord('a')]:
        vis[ord(str[left]) - ord('a')] = False
        left += 1
        
    vis[ord(str[right]) - ord('a')] = True
    
    res = max(res, right - left + 1)
    right += 1
    
left = 0
right = 0
vis = [False]*26

while right < len(str):
    while vis[ord(str[right]) - ord('a')]:
        vis[ord(str[left]) - ord('a')] = False
        left += 1
        
    vis[ord(str[right]) - ord('a')] = True
    
    if right - left + 1 == res:
        count += 1
    
    right += 1

print(count)

str = input()
freq = {}

for ch in str:
    if ch in freq:
        freq[ch] += 1
    else:
        freq[ch] = 1

first = False
for key,value in freq.items():
    if value == 1 and first:
        print(key)
        break
    elif value == 1:
        first = True
